import user_login from "./components/user_login.vue"
import admin_login from "./components/admin_login.vue"
import user_signup from "./components/user_signup.vue"
import welCome from "./components/welcome.vue"
import dashBoard from "./components/dashboard.vue"
import addTheatre from "./components/addtheatre.vue"
import notheatreFound from "./components/notheatrefound.vue"
import editTheatre from "./components/edittheatre.vue"
import deleteTheatre from "./components/deletetheatre.vue"
import editShow from "./components/editshow.vue"
import addShow from "./components/addshow.vue"
import deleteShow from "./components/deleteshow.vue"
import logOut from "./components/logout.vue"
import user_dashBoard from "./components/user_dashboard.vue"
import ticketBook from "./components/ticket_book.vue"
import userBookings from "./components/user_bookings.vue"
import exPort from "./components/export.vue"
import admin_exPort from "./components/export_admin.vue"
import rateShow from "./components/rateShow.vue"
import sumMary from "./components/sumMary.vue"
import SeaRch from "./components/search.vue"
import {createRouter,createWebHistory} from "vue-router"

const routes=[
    {
        name:"welCome",
        component:welCome,
        path:"/"
    },
    {
        name:"user_login",
        component:user_login,
        path:"/user_login"
    },
    {
        name:"user_signup",
        component:user_signup,
        path:"/user_signup"
    },
    {
        name:"admin_login",
        component:admin_login,
        path:"/admin_login"
    },
    {
        name:"dashBoard",
        component:dashBoard,
        path:"/dashboard"
    },
    {
        name:"user_dashBoard",
        component:user_dashBoard,
        path:"/userdashboard"
    },
    {
        name:"addTheatre",
        component:addTheatre,
        path:"/addtheatre"
    },
    {
        name:"notheatreFound",
        component:notheatreFound,
        path:"/notheatrefound"
    },
    {
        name:"editTheatre",
        component:editTheatre,
        path:"/edittheatre/:theatre_id"
    },
    {
        name:"deleteTheatre",
        component:deleteTheatre,
        path:"/deletetheatre/:theatre_id"
    },
    {
        name:"editShow",
        component:editShow,
        path:"/editshow/:theater_id/:show_id"
    },

    {
        name:"addShow",
        component:addShow,
        path:"/addshow/:theatre_id"
    },
    {
        name:"deleteShow",
        component:deleteShow,
        path:"/deleteshow/:theatre_id/:show_id"
    },
    {
        name:"ticketBook",
        component:ticketBook,
        path:"/ticketbooking/:theatre_id/:show_id/:num_tickets"
    },
    {
        name:"userBookings",
        component:userBookings,
        path:"/userbookings"
    },
    {
        name:"exPort",
        component:exPort,
        path:"/userexportdashboard"
    },
    {
        name:"admin_exPort",
        component:admin_exPort,
        path:"/export_theatre/:theatre_id"
    },
    {
        name:"rateShow",
        component:rateShow,
        path:"/rate/:show_id"
    },
    {
        name:"sumMary",
        component:sumMary,
        path:"/summary"
    },
    {
        name:"logOut",
        component:logOut,
        path:"/logout"
    },
    {
        name:"SeaRch",
        component:SeaRch,
        path:"/search"
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router;
