<template>

    <h1>Logout</h1>
    
    </template>
    
    
    <script>
    export default{
        name: "logOut",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
            }
        },
        methods:{
            logOut(){
                fetch(`http://127.0.0.1:5000/api/logout/${this.user_id}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
            })
                .then((res) => res.json())
                .then((data) => {
                console.log(data);
                localStorage.removeItem("user_id");
                localStorage.removeItem("Theatre");
                localStorage.removeItem("token");
                this.$router.push({ name: "welCome" });
                })
                .catch("galat hai");
            }
        },
        mounted(){
            this.logOut()
        },
        }
    </script>