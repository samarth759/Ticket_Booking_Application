<template>

    <h1>Theatre deleted</h1>
    
    </template>
    
    
    <script>
    export default{
        name: "deleteTheatre",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
                theatre_id:this.$route.params.theatre_id
            }
        },
        methods:{
            deleteTheatre(){
                fetch(`http://127.0.0.1:5000/api/theatre/${this.user_id}/${this.theatre_id}`, {
                method: "DELETE",
                headers: { "Content-Type": "application/json",
                'access-token' : localStorage.getItem("token")
             },
            })
                .then((res) => res.json())
                .then((data) => {
                console.log(data);
                this.$router.push({ name: "dashBoard" });
                })
                .catch("galat hai");
            }
        },
        mounted(){
            this.deleteTheatre()
        },
        }
    </script>
    
    