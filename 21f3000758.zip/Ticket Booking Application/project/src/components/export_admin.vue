<template>

    <h1>Downloading!!</h1>
    
    </template>
    
    <script>
    export default{
        name: "admin_exPort",
        data(){
            return{
            user_id:localStorage.getItem("user_id"),
            user_name:localStorage.getItem("user_name"),
            theatre_id:this.$route.params.theatre_id
            }
        },
        methods:{
            admin_exPort(){
                fetch(`http://127.0.0.1:5000/api/export_theatre/${this.user_id}/${this.theatre_id}`, {
                method: "GET",
                headers: { "Content-Type": "application/json",
                'access-token' : localStorage.getItem("token")
               },
            })
                .then((res) => res.json())
                .then((data) => {
                console.log(data.message)
                this.message=data.message
                                if(data.message!="invalid user"){
                                    this.$router.push({ name: "dashBoard" });
                                }
                })
                .catch("galat hai");
            }
        },
        mounted(){
            
            this.admin_exPort();
        },
    }
    </script>