<template>

  <h1>Downloading!!</h1>
  
  </template>
  
  <script>
  export default{
      name: "exPort",
      data(){
          return{
          user_id:localStorage.getItem("user_id"),
          user_name:localStorage.getItem("user_name"),
          }
      },
      methods:{
          exPort(){
              fetch(`http://127.0.0.1:5000/api/userexportdashboard/${this.user_id}`, {
              method: "GET",
              headers: { "Content-Type": "application/json",
              'access-token' : localStorage.getItem("token")
             },
          })
              .then((res) => res.json())
              .then((data) => {
              console.log(data.message)
              this.message=data.message
                              if(data.message!="invalid user"){
                                  this.$router.push({ name: "user_dashBoard" });
                              }
              })
              .catch("galat hai");
          }
      },
      mounted(){
          
          this.exPort();
      },
  }
  </script>