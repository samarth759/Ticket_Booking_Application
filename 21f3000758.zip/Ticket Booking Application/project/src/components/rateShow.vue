<template>
    <div>
        <ul>
          <li><a href="#">Welcome {{user_name}}</a></li>
          <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
          <li style="float:right"><router-link  to="/userbookings/">Bookings</router-link></li>
          <li style="float:right"><router-link  to="/userexportdashboard/">Export</router-link></li> 
        </ul>
        
            <h1>Rate Show</h1>
            <div class="signup_form">
                <br>
                <br>
                Rate : <input type="number" v-model="rate">
                <br>
                <br>
                <button class="btn btn-primary" v-on:click="rateShow()" type="submit">Submit</button>
                <p>{{message}}</p>
                <router-link class="btn btn-success" to="/userdashboard">Dashboard</router-link>
            </div>
        </div>

        </template>
        
        
        <script>
        export default{
            name: "rateShow",
            data(){
                return{
                    user_id:localStorage.getItem("user_id"),
                    rate:0,
                    show_id:this.$route.params.show_id,
                    user_name:localStorage.getItem("user_name"),
                    message:''
                }
            },
            methods:{
                rateShow(){
                    fetch(`http://127.0.0.1:5000/api/show/rate/${this.user_id}/${this.show_id}`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" ,
                    'access-token' : localStorage.getItem("token")
                },
                    body: JSON.stringify({
                    rate:this.rate,
                    }),
                })
                    .then((res) => res.json())
                    .then((data) => {
                    console.log(data);
                    console.log(data.message)
                    this.message=data.message
                    alert("Rated successfully! New rating :"+data.rate)
                    this.$router.push({ name: "userBookings" });
                    })
                    .catch("galat hai");
                }
            }
            }
        
        </script>
        
        <style>
        h1{
            font-size: 50px;
        }
        input{
            width: 400px;
            height: 30px;
            margin: 20px;
        }
        
        ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
          overflow: hidden;
          background-color: #333;
        }
        
        li {
          float: left;
        }
        
        li a {
          display: block;
          color: white;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
        }
        
        li a:hover:not(.active) {
          background-color: #111;
        }
        
        </style>