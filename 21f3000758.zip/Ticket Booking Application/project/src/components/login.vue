

<template>
    <h1>Login</h1>
    <br>
    <div>
        <input :id="id" type="text" v-model="id" placeholder="Enter email">
        <br>
        <br>
        <input :id="password" type="password" v-model="password" placeholder="Enter password">
        <br>
        <br>
        <button type="submit" class="btn btn-primary" v-on:click="logIn()">Submit</button>
        <br>
        <p>{{message}}</p>
        <br>
            <router-link class="btn btn-success" to="/signup">Sign Up</router-link>
    </div>

    
</template>


<script>
export default{
    name: "logIn",
    data(){
        return{
            id:'',
            password:'',
            message:''
        }
    },
    methods:{
        logIn(){
            fetch("http://127.0.0.1:5000/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
            id: this.id,
            password: this.password,
            }),
        })
            .then((res) => res.json())
            .then((data) => {
            console.log(data.token)
            console.log(data.message)
            this.message=data.message
            if(data["user"][2]){
                if(data["user"][3]){
                    if(data["user"][3]==this.password){
                    localStorage.setItem("user_id", data["user"][0]);
                    localStorage.setItem("token", data["token"]);
                    this.$router.push({ name: "dashBoard" });
                    }
                }
            }
            if(data.message=="user does not exists"){
                //this.$router.push({ name: "signUp" });
                this.message="User does not exists! Please signup"
            }
            })
            .catch("galat hai");
        }
        }
    }

</script>


<style>

h1{
    font-size: 50px;
}
input{
    width: 400px;
    height: 30px;
    margin: 20px;
}

</style>