<template>
<div>
    <ul>
      <li><a href="#">Welcome {{user_name}}</a></li>
      <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
      <li style="float:right"><router-link  to="/summary/">Summary</router-link></li>
    </ul>
    
        <h1>Add Show</h1>
        <br>
        <div class="signup_form">
            <input type="text" v-model="name" placeholder="Enter Show Name">
            <br>
            <br>
            <input type="text" v-model="rating" placeholder="Rating">
            <br>
            <br>
            <input type="datetime-local" v-model="datetime" placeholder="Date and Timings">
            <br>
            <br>
            <input type="text" v-model="tags" placeholder="Tags">
            <br>
            <br>
            <input type="text" v-model="num_tickets" placeholder="Number of tickets">
            <br>
            <br>
            <input type="text" v-model="ticket_price" placeholder="Price">
            <br>
            <br>
            <button class="btn btn-primary" v-on:click="addShow()" type="submit">Submit</button>
            <p>{{message}}</p>
            <router-link class="btn btn-success" to="/dashboard">Dashboard</router-link>
        </div>
    </div>
    </template>
    
    
    <script>
    export default{
        name: "addShow",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
                name:'',
                rating:'',
                datetime:'',
                tags:'',
                ticket_price:'',
                message:'',
                num_tickets:'',
                user_name:localStorage.getItem("name"),
                theatre_id:this.$route.params.theatre_id
            }
        },
        methods:{
            addShow(){
                fetch(`http://127.0.0.1:5000/api/show/${this.user_id}/${this.theatre_id}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" ,
                'access-token' : localStorage.getItem("token")
            },
                body: JSON.stringify({
                name: this.name,
                rating: this.rating,
                datetime: this.datetime,
                tags: this.tags,
                ticket_price: this.ticket_price,
                num_tickets: this.num_tickets
                }),
            })
                .then((res) => res.json())
                .then((data) => {
                console.log(data);
                console.log(data.message)
                this.message=data.message
                if(data.name){
                    if(data.rating){
                        if(data.datetime){
                                if(data.message!="show already exists"){
                                    this.$router.push({ name: "dashBoard" });
                                }
                        }
                    }
                }
                })
                .catch("galat hai");
            }
        }
        }
    
    </script>
    
    <style>
    h1{
        font-size: 50px;
    }
    input{
        width: 400px;
        height: 30px;
        margin: 20px;
    }
    
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    
    li {
      float: left;
    }
    
    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    li a:hover:not(.active) {
      background-color: #111;
    }
    
    </style>