

<template>
    <div>
    <h1>Admin Login</h1>
    <br>
    <div>
        <input :id="username" type="text" v-model="username" placeholder="Enter username">
        <br>
        <br>
        <input :id="password" type="password" v-model="password" placeholder="Enter password">
        <br>
        <br>
        <button type="submit" class="btn btn-primary" v-on:click="logIn()">Submit</button>
        <br>
        <p>{{message}}</p>
        <br>
    </div>
</div>

    
</template>


<script>
export default{
    name: "admin_login",
    data(){
        return{
            username:'',
            password:'',
            message:''
        }
    },
    methods:{
        logIn(){
            fetch("http://127.0.0.1:5000/api/admin_login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
            username: this.username,
            password: this.password,
            }),
        })
            .then((res) => res.json())
            .then((data) => {
            console.log(data.token)
            console.log(data.message)
            this.message=data.message

            if(this.message!='Please enter Username'){
                if(this.message!='Please enter password'){
                    if(this.message!='Admin does not exists!'){
                        if(this.message!='This user is not an Admin'){
                            if(this.message!='Wrong password'){
                                localStorage.setItem("user_id", data["user"][0]);
                                localStorage.setItem("name", data["user"][1]);
                                localStorage.setItem("token", data["token"]);
                                alert("Login successful!")
                                this.$router.push({ name: "dashBoard" });
                            }
                        }
                    }
                }
            }
            })
            .catch("galat hai");
        }
        }
    }

</script>


<style>

h1{
    font-size: 50px;
}
input{
    width: 400px;
    height: 30px;
    margin: 20px;
}

</style>