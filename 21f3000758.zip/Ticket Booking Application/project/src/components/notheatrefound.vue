<template>
<div>
    <ul>
      <li><a href="#">Welcome {{user_name}}</a></li>
      <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
      <li style="float:right"><router-link  to="/summary/">Summary</router-link></li>
      <!-- <li style="float:right"><router-link  to="/export/">Export</router-link></li> -->
    </ul>
    
    
        <h1>Dashboard</h1>
        <br>
        <div>No Theatre!!
          <br>
          <br>
         <router-link class="btn btn-success" to="/addtheatre">Add a Theatre</router-link>
        </div>
    </div>
    </template>
    
    <script>
    export default{
        name: "notheatreFound",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
                user_name:localStorage.getItem("name"),
            }
        },
    }
    </script>
    
    
    <style>
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    
    li {
      float: left;
    }
    
    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    li a:hover:not(.active) {
      background-color: #111;
    }
    
    </style>