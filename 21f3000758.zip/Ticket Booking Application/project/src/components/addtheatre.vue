<template>
<div>
    <ul>
      <li><a href="#">Welcome {{user_name}}</a></li>
      <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
      <li style="float:right"><router-link  to="/summary/">Summary</router-link></li>
    </ul>
    
        <h1>Add Theatre</h1>
        <br>
        <div class="signup_form">
            <input type="text" v-model="name" placeholder="Enter Theatre name">
            <br>
            <br>
            <input type="text" v-model="place" placeholder="Enter Place and Location">
            <br>
            <br>
            <input type="text" v-model="capacity" placeholder="Enter Capacity">
            <br>
            <br>
            <button class="btn btn-primary" v-on:click="addTheatre()" type="submit">Submit</button>
    
            <p>{{message}}</p>
            <router-link class="btn btn-success" to="/dashboard">Dashboard</router-link>
        </div>
    </div>
    </template>
    
    
    <script>
    export default{
        name: "addTheatre",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
                name:'',
                place:'',
                capacity:0,
                user_name:localStorage.getItem("name"),
                message:''
            }
        },
        methods:{
            addTheatre(){
                fetch(`http://127.0.0.1:5000/api/theatre/${this.user_id}`, {
                method: "POST",
                headers: { "Content-Type": "application/json",
                'access-token' : localStorage.getItem("token")
             },
                body: JSON.stringify({
                name: this.name,
                place: this.place,
                capacity: this.capacity,
                L:JSON.parse(localStorage.getItem('Theatre')),
                }),
            })
                .then((res) => res.json())
                .then((data) => {
                this.message=data.message
                console.log(this.message)
    
                if(data.name){
                    if(data.place){
                        if(data.capacity){
                            if(data.message!="Theatre already exists"){
                                this.$router.push({ name: "dashBoard" });
                            }
                        }  
                    }
                }
                })
                .catch("galat hai");
            }
            }
        }
    
    </script>
    
    <style>
    h1{
        font-size: 50px;
    }
    input{
        width: 400px;
        height: 30px;
        margin: 20px;
    }
    
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    
    li {
      float: left;
    }
    
    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    li a:hover:not(.active) {
      background-color: #111;
    }
    
    </style>