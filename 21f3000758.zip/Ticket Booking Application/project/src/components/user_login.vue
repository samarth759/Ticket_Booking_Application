

<template>
    <div>
    <h1>User Login</h1>
    <br>
    <div>
        <input :id="username" type="username" v-model="username" placeholder="Enter username">
        <br>
        <br>
        <input :id="password" type="password" v-model="password" placeholder="Enter password">
        <br>
        <br>
        <button type="submit" class="btn btn-primary" v-on:click="logIn()">Submit</button>
        <br>
        <p>{{message}}</p>
        <br>
            <router-link class="btn btn-success" to="/user_signup">Sign Up</router-link>
    </div>
</div>

    
</template>


<script>
export default{
    name: "user_login",
    data(){
        return{
            username:'',
            password:'',
            message:''
        }
    },
    methods:{
        logIn(){
            fetch("http://127.0.0.1:5000/api/user_login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
            username: this.username,
            password: this.password,
            }),
        })
            .then((res) => res.json())
            .then((data) => {
            console.log(data.token)
            this.message=data.message
            console.log(data)

            if(this.message!='Please enter Username'){
                if(this.message!='Please enter password'){
                    if(this.message!='User does not exists! Please signup'){
                        if(this.message!='This username does not belong to an User'){
                            if(this.message!='Wrong password'){
                                localStorage.setItem("user_id", data["user"][0]);
                                localStorage.setItem("name", data["user"][1]);
                                localStorage.setItem("token", data["token"]);
                                alert("Login successful!")
                                this.$router.push({ name: "user_dashBoard" });
                            }
                        }
                    }
                }
            }
            if(data.message=="User does not exists! Please signup"){
                this.$router.push({ name: "user_signup" });
                this.message="User does not exists! Please signup"
            }
            })
            .catch("galat hai");
        }
        }
    }

</script>


<style>

h1{
    font-size: 50px;
}
input{
    width: 400px;
    height: 30px;
    margin: 20px;
}

</style>