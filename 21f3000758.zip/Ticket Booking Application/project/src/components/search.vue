
   <template>
    <div>
        <ul>
            <li><a href="#">Welcome {{user_name}}</a></li>
            <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
             <li style="float:right"><router-link  to="/userbookings/">Bookings</router-link></li> 
             <li style="float:right"><router-link  to="/userexportdashboard/">Export</router-link></li>
             <li style="float:right"><router-link  to="/userdashboard/">Dashboard</router-link></li> 
             
          </ul>
      <h1>Search Theatres and Shows</h1>
      <div>
        <input v-model="searchText" type="text" placeholder="Enter location or tags" />
        <button @click="searchTheatres">Search Theatres by Location</button>
        <button @click="searchShowsByTags">Search Shows by Tags</button>
        <button @click="searchShowsByRating">Search Shows by Rating</button>
      </div>
  
      <!-- Display search results -->
      <div v-if="searchResults.length > 0" class="search-results">
        <h2>Search Results:</h2>
        <ul class="abcd" v-for="(result, index) in searchResults" :key="index">
          <!-- Display theatre name when searching by location -->
          <li v-if="searchType === 'theatres'">{{ result.name }}</li>
          <!-- Display show name when searching by tags or rating -->
          <li v-else-if="searchType === 'shows'">{{ result.name }}</li>
        </ul>
      </div>
      <div v-else>
        <p class="no-results">No results found.</p>
      </div>
    </div>
  </template>
  

  <script>
  export default {
    name: "SeaRch",
    data() {
      return {
        searchText: '',
        searchResults: [],
        message:'vj',
        user_id:localStorage.getItem("user_id"),
        L:[],
        user_name:localStorage.getItem("name"),
        searchType: '', // to store the current search type (theatres or shows)
      };
    },
    methods: {
      async searchTheatres() {
        this.searchType = 'theatres';
        try {
          const response = await fetch('http://127.0.0.1:5000/api/searchtheatresbylocation', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              place: this.searchText,
            }),
          });
          if (response.ok) {
            this.searchResults = await response.json();
          } else {
            this.searchResults = [];
          }
        } catch (error) {
          console.error('Error searching theatres:', error);
        }
      },
      async searchShowsByTags() {
        this.searchType = 'shows';
        try {
          const response = await fetch('http://127.0.0.1:5000/api/searchshowsbytags', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              tags: this.searchText,
            }),
          });
          if (response.ok) {
            this.searchResults = await response.json();
          } else {
            this.searchResults = [];
          }
        } catch (error) {
          console.error('Error searching shows by tags:', error);
        }
      },
      async searchShowsByRating() {
        this.searchType = 'shows';
        try {
          const response = await fetch('http://127.0.0.1:5000/api/searchshowsbyrating', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              rating: parseFloat(this.searchText),
            }),
          });
          if (response.ok) {
            this.searchResults = await response.json();
          } else {
            this.searchResults = [];
          }
        } catch (error) {
          console.error('Error searching shows by rating:', error);
        }
      },
    },
  };
  </script>
  
  <style>
      
      
  .dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown-content a:hover {background-color: #f1f1f1}
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
  
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  
  .abcd {
    display: block;
    background-color: #edeaf1;
  }
  li {
    float: left;
  }
  
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  li a:hover:not(.active) {
    background-color: #111;
  }
  
  </style>
  