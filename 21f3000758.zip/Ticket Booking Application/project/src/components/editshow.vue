<template>
<div>
    <ul>
      <li><a href="#">Welcome {{user_name}}</a></li>
      <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
      <li style="float:right"><router-link  to="/summary/">Summary</router-link></li>
    </ul>
    
        <h1>Edit Show</h1>
        <br>
        <div class="signup_form">

      <br>
      <br>
    
            Show Name : <input type="text" v-model="name">
            <br>
            <br>
            Date and Timings : <input type="datetime-local" v-model="datetime">
            <br>
            <br>
            Tags : <input type="text" v-model="tags">
            <br>
            <br>
            Number of tickets : <input type="text" v-model="num_tickets">
            <br>
            <br>
            Price : <input type="text" v-model="ticket_price">
            <br>
            <br>
            <button class="btn btn-primary" v-on:click="editShow()" type="submit">Submit</button>
            <p>{{message}}</p>
            <router-link class="btn btn-success" to="/dashboard">Dashboard</router-link>
        </div>
    </div>
    </template>
    
    
    <script>
    export default{
        name: "editShow",
        data(){
            return{
                user_id:localStorage.getItem("user_id"),
                name: '',
                datetime: '',
                tags: '',
                ticket_price: 0,
                message:'',
                num_tickets:0,
                user_name:localStorage.getItem("name"),
                theatre:0,
                L:JSON.parse(localStorage.getItem('Theatre')),
                theatre_id:this.$route.params.theater_id,
                show_id:this.$route.params.show_id
            }
        },
        methods:{
            editShow(){
                fetch(`http://127.0.0.1:5000/api/show/${this.user_id}/${this.theatre_id}/${this.show_id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json",
                'access-token' : localStorage.getItem("token")
               },
                body: JSON.stringify({
                theatre:this.theatre,
                name: this.name,
                datetime: this.datetime,
                tags: this.tags,
                ticket_price: this.ticket_price,
                num_tickets:this.num_tickets
                }),
            })
                .then((res) => res.json())
                .then((data) => {
                console.log(data.message)
                this.message=data.message
                                if(data.message!="invalid show"){
                                    this.$router.push({ name: "dashBoard" });
                                }
                })
                .catch("galat hai");
            }
        }
    }
    </script>
    
    <style>
    h1{
        font-size: 50px;
    }
    input{
        width: 400px;
        height: 30px;
        margin: 20px;
    }
    .switch {
      position: relative;
      display: inline-block;
      width: 60px;
      height: 34px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:focus + .slider {
      box-shadow: 0 0 1px #2196F3;
    }
    
    input:checked + .slider:before {
      -webkit-transform: translateX(26px);
      -ms-transform: translateX(26px);
      transform: translateX(26px);
    }
    
    /* Rounded sliders */
    .slider.round {
      border-radius: 34px;
    }
    
    .slider.round:before {
      border-radius: 50%;
    }
    
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    
    li {
      float: left;
    }
    
    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    li a:hover:not(.active) {
      background-color: #111;
    }
    
    </style>