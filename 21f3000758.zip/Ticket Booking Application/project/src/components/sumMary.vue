<template>

    <ul>
      <li><a href="#">Welcome {{user_name}}</a></li>
      <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
      <li style="float:right"><router-link  to="/dashboard/">Home</router-link></li>
    </ul>
    
        <h1>Summary</h1>
    
    
        <br>
        <div class="container">
            <div class="row">
                    <div :key="i.theatre_id" v-for="i in this.L" class="col-lg-2">
      
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">{{ i.name }}</h5>
                                <br>
                                <img :src="require(`../assets/${i.trend}`)" alt="">
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        
        </template> 
        
        
    <script>
    
    
        export default{
          name: "sumMary",
        data(){
            return{
                message:'vj',
                user_id:localStorage.getItem("user_id"),
                user_name:localStorage.getItem("name"),
                L:[],
            }
        },
        methods:{
            
            sumMary(){
                fetch(`http://127.0.0.1:5000/api/summary/${this.user_id}`, {
                method: "GET",
                headers: { "Content-Type": "application/json",
                'access-token' : localStorage.getItem("token")
             },
            })
                .then((res) => res.json())
                .then((data) => {
                    // this.message=data.message
                    this.L=data;
                    // this.dashBoard()
                    console.log(data)
                    console.log(this.L)

                    
                })
                .catch("galat hai"); 
            }
            },
    
        mounted(){
            
            this.sumMary();
        },
        }
    </script>
    
    <style>
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    
    li {
      float: left;
    }
    
    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    li a:hover:not(.active) {
      background-color: #111;
    }
    
    .completed{
        color: green;
    }
    
    .deadline{
        color: red;
    }
    
    img{
        width: 130px;
        height: 150px;
    }
    
    </style>