
<template>
    <div>
      <ul>
        <li><a href="#">Welcome {{user_name}}</a></li>
        <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
         <li style="float:right"><router-link  to="/userbookings/">Bookings</router-link></li> 
         <li style="float:right"><router-link  to="/userexportdashboard/">Export</router-link></li>
         <li style="float:right"><router-link  to="/search/">Search</router-link></li> 
         
      </ul>
      
      <br>
    
          <h1>Dashboard</h1>
      <br>
          <div class="container">
              <div class="row">
                      <div :key="i.theatre_id" v-for="i in this.L" class="col-lg-2">
                          
                          <div class="show">
                              <div class="show-body">
                                  <h5 class="show-title">{{ i.name }}</h5>
                                  <p class="show-place">{{ i.place }}</p>
      
                                              <div class="row" :key="j.show_id" v-for="j in i.show_list">
                                              <div class="show" style="width: 18rem;">
                                              <div class="show-body">
                                                  <!-- <router-link class="btn btn-outline-secondary btn-md" :to="'/viewshow/'+ i.theatre_id +'/'+ j.show_id">{{j.name}}</router-link> -->
                                                  <div class="btn btn-outline-secondary btn-md">{{j.name}}</div>
                                                  <br>
                                                  <br>
                                                  <p>Timings : {{j.datetime}}</p>
                                                  <p>Ratings : {{j.rating}}</p>
                                                  <br>
                                                  <br>
                                                  <router-link class="btn btn-danger btn-sm" :to="'/ticketbooking/'+ i.theatre_id+'/'+ j.show_id+'/'+j.num_tickets">Book Show</router-link>
                                  <br>
                                  <br>
                                  <br>
                                              </div>
                                              </div>
                                              </div>
                              </div>
                          </div>
                      </div>
              </div>
          </div>
              <br>
              <br>
            </div> 
      </template>
      
      
      <script>
      
      export default{
          name: "user_dashBoard",
          data(){
              return{
                  message:'vj',
                  user_id:localStorage.getItem("user_id"),
                  L:[],
                  user_name:localStorage.getItem("name"),
              }
          },
          methods:{
      
            user_dashBoard(){
                  fetch(`http://127.0.0.1:5000/api/userdashboard/${this.user_id}`, {
                  method: "GET",
                  headers: { "Content-Type": "application/json",
                  'access-token' : localStorage.getItem("token")
                 },
              })
                  .then((res) => res.json())
                  .then((data) => {
                      console.log(data)
                      this.message=data.message
                      this.L=data
                      if(this.message=="no theatre found"){
                          this.$router.push({ name: "notheatreFound" });
                      }
                      localStorage.setItem('user_name', this.name);
                      localStorage.setItem('Theatre', JSON.stringify(data));
                  })
                  .catch("galat hai"); 
              }
              },
      
          mounted(){
              this.user_dashBoard()
          },
              
      }
      </script>
      
      
      <style>
      
      
      .dropbtn {
        background-color: #4CAF50;
        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
        cursor: pointer;
      }
      
      .dropdown {
        position: relative;
        display: inline-block;
      }
      
      .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
      }
      
      .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
      }
      
      .dropdown-content a:hover {background-color: #f1f1f1}
      
      .dropdown:hover .dropdown-content {
        display: block;
      }
      
      .dropdown:hover .dropbtn {
        background-color: #3e8e41;
      }
      
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #333;
      }
      
      li {
        float: left;
      }
      
      li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
      }
      
      li a:hover:not(.active) {
        background-color: #111;
      }
      
      </style>
      