
<template>
<div>
    <h1>User Signup</h1>
    <div class="signup_form">
        <br>
        <input type="text" v-model="name" placeholder="Enter name">
        <br>
        <br>
        <input type="email" v-model="username" placeholder="Enter Username">
        <br>
        <br>
        <input type="password" v-model="password" placeholder="Enter password">
        <br>
        <br>
        <button class="btn btn-primary" v-on:click="signUp()" type="submit">Submit</button>
        <br>
        <p>{{message}}</p>
        <router-link class="btn btn-success" to="/user_login">Login</router-link>
    </div>
</div>
</template>


<script>
export default{
    name: "user_signup",
    data(){
        return{
            name:'',
            username:'',
            password:'',
            message:''
        }
    },
    methods:{
        signUp(){
            fetch("http://127.0.0.1:5000/api/user_signup", {
            method: "POST",
            headers: { "Content-Type": "application/json", },
            body: JSON.stringify({
            name: this.name,
            username: this.username,
            password: this.password,
            }),
        })
            .then((res) => res.json())
            .then((data) => {
            console.log(data);
            this.message=data.message
            console.log(this.message)
            if(data.message!="User already exists"){
                            alert("Signup successful! Please go to login page")
                            this.$router.push({ name: "user_login" });
                        }
            })
            .catch("galat hai");
        }
    }
}
</script>

<style>
h1{
    font-size: 50px;
}
input{
    width: 400px;
    height: 30px;
    margin: 20px;
}


</style>