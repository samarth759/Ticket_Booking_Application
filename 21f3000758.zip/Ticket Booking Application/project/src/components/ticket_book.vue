<template>
    <div>
        <ul>
          <li><a href="#">Welcome {{user_name}}</a></li>
          <li style="float:right"><router-link  to="/logout/">Logout</router-link></li>
          <li style="float:right"><router-link  to="/userbookings/">Bookings</router-link></li>
          <li style="float:right"><router-link  to="/userexportdashboard/">Export</router-link></li>
          <li style="float:right"><router-link  to="/search/">Search</router-link></li>
        </ul>
        
            <h1>Book Show</h1>
            <br>
            <div class="signup_form">
                Available tickets : {{num_tickets}}
                <br>
                <br>
                Number of tickets : <input type="number" v-model="booked_tickets" placeholder="booked_tickets">
                <br>
                <br>
                <button class="btn btn-primary" v-on:click="ticketBook()" type="submit">Submit</button>
                <p>{{message}}</p>
                <router-link class="btn btn-success" to="/userdashboard">Dashboard</router-link>
            </div>
        </div>

        </template>
        
        
        <script>
        export default{
            name: "ticketBook",
            data(){
                return{
                    user_id:localStorage.getItem("user_id"),
                    booked_tickets:0,
                    num_tickets:this.$route.params.num_tickets,
                    price:0,
                    show_id:this.$route.params.show_id,
                    user_name:localStorage.getItem("name"),
                    theatre_id:this.$route.params.theatre_id,
                    message:''
                }
            },
            methods:{
                ticketBook(){
                    fetch(`http://127.0.0.1:5000/api/ticketbooking/${this.user_id}/${this.theatre_id}/${this.show_id}/${this.num_tickets}`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" ,
                    'access-token' : localStorage.getItem("token")
                },
                    body: JSON.stringify({
                    booked_tickets:this.booked_tickets,
                    num_tickets:this.num_tickets,
                    price:this.price,
                    }),
                })
                    .then((res) => res.json())
                    .then((data) => {
                    console.log(data);
                    console.log(data.message)
                    this.message=data.message
                    if(data.message!="Admins are not allowed to book tickets"){
                        if(data.message!="Show not found"){
                            if(data.message!="Number of tickets booked should be greater than 0"){
                                    if(data.message!="This show is Houseful"){
                                        if(data.message!="Not enough tickets available for booking"){
                                            alert("Tickets confirmed! Total price :"+data.total)
                                        this.$router.push({ name: "user_dashBoard" });
                                        }
                                    }
                                }
                            }
                        }
                    })
                    .catch("galat hai");
                }
            }
            }
        
        </script>
        
        <style>
        h1{
            font-size: 50px;
        }
        input{
            width: 400px;
            height: 30px;
            margin: 20px;
        }
        
        ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
          overflow: hidden;
          background-color: #333;
        }
        
        li {
          float: left;
        }
        
        li a {
          display: block;
          color: white;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
        }
        
        li a:hover:not(.active) {
          background-color: #111;
        }
        
        </style>