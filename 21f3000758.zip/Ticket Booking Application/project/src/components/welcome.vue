
<template>
    <div class="welcome">
      <h1>Welcome to the Ticket Show</h1>
      <div class="buttons">
        <router-link class="btn btn-primary" to="/user_login">User Login</router-link>
        <router-link class="btn btn-primary" to="/admin_login">Admin Login</router-link>
      </div>
    </div>
  </template>

  <script>
  export default{
      name: "welCome"
  }
  </script>
  
  <style>
  .welcome {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  h1 {
    font-size: 32px;
    margin-bottom: 20px;
  }
  
  .buttons {
    display: flex;
    gap: 20px;
  }
  
  .btn {
    font-size: 18px;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
  }
  </style>
  